const sizes = [
  { size: "S",  use: 2 },
  { size: "M",  use: 2.2 },
  { size: "L",  use: 2.5 },
  { size: "XL", use: 2.8 },
];
export default sizes;