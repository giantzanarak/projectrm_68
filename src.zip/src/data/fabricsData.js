// src/data/fabricsData.js
const fabrics = [
  {
    id: 1,
    roll_code: "ผืนที่ 1",
    type: "ผ้าไหม",
    name: "ผ้าไหมลายดอก ผืนที่ 1",
    price: 450,
    stock: 380,
  },
  {
    id: 2,
    roll_code: "ผืนที่ 2",
    type: "ผ้าฝ้าย",
    name: "ผ้าฝ้ายพื้นเมือง ผืนที่ 2",
    price: 280,
    stock: 380,
  },
];

export default fabrics;